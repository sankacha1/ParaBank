package com.parabank.executor;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/tes/resources"},
		glue={"stepDefinitions"},
		plugin = {"html:target/htmlreports","pretty","json:rarget/cucumber.json"},
		tags= {"@Test1"},
		monochrome=true
		)
public class TestAutomationRunner {
	
}
