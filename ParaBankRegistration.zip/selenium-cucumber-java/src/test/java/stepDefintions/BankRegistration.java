package stepDefintions;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;

public class BankRegistration{

	@Given("^Customer registers an account with ParaBank using the below data$")
		public void user_register(DataTable Usercredentials) {
		System.out.println("hshs");
		
	}
	
}
	
	/*
	public void invokeBrowser(){
		try {
			System.out.println("aa");
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium Library\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			System.out.println("Cursor here");
			
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
			driver.get("https://parabank.parasoft.com/parabank/register.htm");
		//	searchCourse();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}		
	
*/		
 /*@When("^Customer opens a new checking account with \"(.*?)\" dollors$")
	public void customer_opens_a_new_checking_account_with_dollors(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Customer opens a new Saving account with \"(.*?)\" dollors$")
	public void customer_opens_a_new_Saving_account_with_dollors(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Customer transfers \"(.*?)\" dollors from Checking to Savings account$")
	public void customer_transfers_dollors_from_Checking_to_Savings_account(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify  checking account balance decreased by  \"(.*?)\"$")
	public void verify_checking_account_balance_decreased_by(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify  saving account balance increased by  \"(.*?)\"$")
	public void verify_saving_account_balance_increased_by(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Customer transfers \"(.*?)\" dollors from Checking to Savings account$")
	public void customer_transfers_dollors_from_Checking_to_Savings_account(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Customer transfers total transfered amount from Savings to Checking Account$")
	public void customer_transfers_total_transfered_amount_from_Savings_to_Checking_Account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify Checking account balance is set back to \"(.*?)\"$")
	public void verify_Checking_account_balance_is_set_back_to(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Verify Saving account balance is set back to \"(.*?)\"$")
	public void verify_Saving_account_balance_is_set_back_to(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
*/
	
/*	
public static void main(String[] args) {
	
	System.out.println("bb");
	BankRegistration myobj = new BankRegistration();
    myobj.invokeBrowser();
  
	
}

*/
